AKASH INTERN - COLLEGE INTERNSHIP PORTAL
=====================================

DATABASE CONFIGURATION
- Host: db01.dbhost.dev
- Port: 5051
- Database: db_455mk9def
- Username: user_455mk9def
- PHP must have pdo_mysql enabled.
- The database user needs CREATE, SELECT, INSERT and UPDATE permissions on AKASH INTERN_portal_store.
- If table creation is restricted, select the database in your hosting console and import database.sql.
- Environment variables AKASH INTERN_DB_HOST, AKASH INTERN_DB_PORT, AKASH INTERN_DB_NAME, AKASH INTERN_DB_USER and AKASH INTERN_DB_PASS override the packaged defaults.

STORAGE DESIGN
The existing app uses array-based records; this build persists the portal state as JSON in one MySQL row (AKASH INTERN_portal_store, id=1), so the rest of the pages retain their current interface.

RUN
1. Extract the ZIP.
2. Confirm pdo_mysql is enabled.
3. Import database.sql if needed.
4. Ensure uploads/ is writable by PHP.
5. Start: php -S 0.0.0.0:8080 -t internship-portal
6. Open your hosting provider's forwarded URL and test student/company registration.

SECURITY
This ZIP contains the database credentials supplied for this project. Keep it private and rotate the password if shared publicly.
