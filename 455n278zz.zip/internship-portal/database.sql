
CREATE TABLE IF NOT EXISTS `INTERN_portal_store` (
    `id` TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    `payload` LONGTEXT NOT NULL,
    `updated_at` TIMESTAMP NOT NULL
        DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `INTERN_portal_store` (`id`, `payload`)
VALUES (
    1,
    '{"users":[],"students":[],"companies":[],"internships":[],"applications":[],"counters":{"users":0,"students":0,"companies":0,"internships":0,"applications":0}}'
);