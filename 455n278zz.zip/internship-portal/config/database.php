<?php
/** AKASH INTERN Internship Portal MySQL storage layer. Environment variables override defaults. */
if (!defined('DB_HOST')) define('DB_HOST', getenv('AKASH_INTERN_DB_HOST') ?: 'db01.dbhost.dev');
if (!defined('DB_PORT')) define('DB_PORT', (int)(getenv('AKASH_INTERN_DB_PORT') ?: 5051));
if (!defined('DB_NAME')) define('DB_NAME', getenv('AKASH_INTERN_DB_NAME') ?: 'db_455mk9def');
if (!defined('DB_USER')) define('DB_USER', getenv('AKASH_INTERN_DB_USER') ?: 'user_455mk9def');
if (!defined('DB_PASS')) define('DB_PASS', getenv('AKASH_INTERN_DB_PASS') ?: 'p455mk9def');

function db_connection(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    if (!extension_loaded('pdo_mysql')) {
        throw new RuntimeException('The PHP pdo_mysql extension is required. Enable pdo_mysql in your PHP hosting settings.');
    }
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function db_default(): array {
    return ['users'=>[], 'students'=>[], 'companies'=>[], 'internships'=>[], 'applications'=>[],
        'counters'=>['users'=>0,'students'=>0,'companies'=>0,'internships'=>0,'applications'=>0]];
}

function db_boot(): void {
    $pdo = db_connection();
    $pdo->exec("CREATE TABLE IF NOT EXISTS INTERN_portal_store (
        id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
        payload LONGTEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $stmt = $pdo->prepare('SELECT id FROM INTERN_portal_store WHERE id = 1');
    $stmt->execute();
    if (!$stmt->fetch()) {
        $insert = $pdo->prepare('INSERT IGNORE INTO INTERN_portal_store (id, payload) VALUES (1, :payload)');
        $insert->execute(['payload'=>json_encode(db_default(), JSON_UNESCAPED_UNICODE)]);
    }
}

function db_load(): array {
    db_boot();
    $stmt = db_connection()->prepare('SELECT payload FROM INTERN_portal_store WHERE id = 1');
    $stmt->execute();
    $raw = $stmt->fetchColumn();
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($data)) $data = db_default();
    foreach (db_default() as $key=>$value) {
        if (!isset($data[$key]) || !is_array($data[$key])) $data[$key] = $value;
    }
    if (!isset($data['counters']) || !is_array($data['counters'])) $data['counters'] = db_default()['counters'];
    foreach (['users','students','companies','internships','applications'] as $table) {
        $maxId = 0;
        foreach ($data[$table] as $row) $maxId = max($maxId, (int)($row['id'] ?? 0));
        $data['counters'][$table] = max((int)($data['counters'][$table] ?? 0), $maxId);
    }
    return $data;
}

function db_save(array $data): bool {
    db_boot();
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    $stmt = db_connection()->prepare('INSERT INTO INTERN_portal_store (id, payload) VALUES (1, :payload) ON DUPLICATE KEY UPDATE payload = VALUES(payload)');
    return $stmt->execute(['payload'=>$json]);
}
function db_next_id(array &$data, string $table): int {
    $data['counters'][$table] = (int)($data['counters'][$table] ?? 0) + 1;
    return $data['counters'][$table];
}
function db_now(): string { return date('Y-m-d H:i:s'); }
function db_find_user_by_email(array $data, string $email): ?array {
    foreach ($data['users'] as $user) if (strcasecmp((string)($user['email'] ?? ''), $email) === 0) return $user;
    return null;
}
function db_user(array $data, int $id): ?array {
    foreach ($data['users'] as $user) if ((int)($user['id'] ?? 0) === $id) return $user;
    return null;
}
function db_student_by_user(array $data, int $userId): ?array {
    foreach ($data['students'] as $row) if ((int)($row['user_id'] ?? 0) === $userId) return $row;
    return null;
}
function db_company_by_user(array $data, int $userId): ?array {
    foreach ($data['companies'] as $row) if ((int)($row['user_id'] ?? 0) === $userId) return $row;
    return null;
}
function db_company(array $data, int $id): ?array {
    foreach ($data['companies'] as $row) if ((int)($row['id'] ?? 0) === $id) return $row;
    return null;
}
function db_internship(array $data, int $id): ?array {
    foreach ($data['internships'] as $row) if ((int)($row['id'] ?? 0) === $id) return $row;
    return null;
}
function db_sort_newest(array &$rows, string $field = 'created_at'): void {
    usort($rows, function ($a, $b) use ($field) { return strcmp((string)($b[$field] ?? ''), (string)($a[$field] ?? '')); });
}
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function flash(string $type, string $message): void { $_SESSION['flash'] = ['type'=>$type, 'message'=>$message]; }
function take_flash(): ?array { $flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $flash; }
function require_role(string $role, string $loginPath = '../login.php'): void {
    if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== $role) { header('Location: ' . $loginPath); exit; }
}
function status_class(string $status): string { return strtolower(str_replace(' ', '-', $status)); }
?>
